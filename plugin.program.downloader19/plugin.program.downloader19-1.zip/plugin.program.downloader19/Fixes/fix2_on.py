﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import os
import re

# 🔓 ΜΑΖΙΚΗ ΕΝΕΡΓΟΠΟΙΗΣΗ BACKGROUND SERVICES (ΣΙΩΠΗΛΟ BYPASS)
try:
    # 🎯 ΟΡΙΖΟΥΜΕ ΤΑ ADDONS ΠΟΥ ΘΕΛΟΥΜΕ ΝΑ ΕΠΑΝΑΦΕΡΟΥΜΕ
    target_addons = [
        "plugin.video.the-loop",
        "plugin.video.madtitansports"
    ]

    for addon_id in target_addons:
        xml_path = xbmcvfs.translatePath(f'special://home/addons/{addon_id}/addon.xml')
        
        # Ο κώδικας προχωράει ΜΟΝΟ αν το πρόσθετο είναι εγκατεστημένο
        if os.path.exists(xml_path):
            with open(xml_path, 'r', encoding='utf-8') as f:
                xml_content = f.read()
            
            # 🔍 ΕΛΕΓΧΟΣ: Αν το service είναι απενεργοποιημένο (έχει ως library το "service.py.disabled")
            if 'library="service.py.disabled"' in xml_content or "library='service.py.disabled'" in xml_content:
                xbmc.log(f"[Master_Build] Εντοπίστηκε απενεργοποιημένο service στο {addon_id}. Επαναφορά σε ενεργό...", xbmc.LOGINFO)
                
                # 🔄 ΑΝΤΙΚΑΤΑΣΤΑΣΗ: Μετατρέπουμε το .disabled πίσω στο κανονικό service.py
                xml_content = xml_content.replace('library="service.py.disabled"', 'library="service.py"')
                xml_content = xml_content.replace("library='service.py.disabled'", "library='service.py'")
                
                # Εγγραφή του διορθωμένου XML πίσω στο δίσκο
                with open(xml_path, 'w', encoding='utf-8') as f:
                    f.write(xml_content)
                xbmc.log(f"[Master_Build] Το service του {addon_id} ενεργοποιήθηκε επιτυχώς (service.py.disabled ➡️ service.py).", xbmc.LOGINFO)
            else:
                xbmc.log(f"[Master_Build] Το service του {addon_id} είναι ήδη ενεργό ή δεν έχει service tag.", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Master_Build] Παράκαμψη: Το {addon_id} δεν είναι εγκατεστημένο.", xbmc.LOGINFO)
            
except Exception as e:
    xbmc.log(f"[Master_Build] Σφάλμα κατά τη μεθοδευμένη ενεργοποίηση services: {str(e)}", xbmc.LOGERROR)

xbmc.sleep(100)
