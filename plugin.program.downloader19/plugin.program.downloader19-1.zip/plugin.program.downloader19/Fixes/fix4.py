﻿# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------
# 🧼 ΚΑΡΦΩΤΗ ΔΙΑΓΡΑΦΗ ΠΡΟΒΛΗΜΑΤΙΚΗΣ BETA (ALIVEGR TARGET LAYER)
# ----------------------------------------------------------------------
try:
	import shutil, os, re, xbmcvfs, xbmcgui
	
	addon_to_delete = "plugin.video.AliveGR"
	target_delete_version = "2.99.99" # 🎯 Η ακριβής, προβληματική έκδοση-στόχος!
	
	wb_xml_path = xbmcvfs.translatePath(f'special://home/addons/{addon_to_delete}/addon.xml')
	wb_folder_path = xbmcvfs.translatePath(f'special://home/addons/{addon_to_delete}/')
	wb_icon_path = f'special://home/addons/{addon_to_delete}/icon.png'
	
	# Ο κώδικας προχωράει ΜΟΝΟ αν το πρόσθετο είναι όντως εγκατεστημένο στον δίσκο
	if os.path.exists(wb_xml_path):
		with open(wb_xml_path, 'r', encoding='utf-8') as f:
			wb_xml_content = f.read()
			
		# 🔍 Ανάγνωση τρέχουσας έκδοσης από το XML
		wb_current_version = ""
		wb_version_match = re.search(r'<addon\s+.*?version="(.*?)".*?>', wb_xml_content)
		if wb_version_match:
			wb_current_version = wb_version_match.group(1)
			
		# 🎯 ΑΠΟΛΥΤΟ ΚΡΙΤΗΡΙΟ: Διαγραφή ΜΟΝΟ αν η έκδοση είναι ΑΚΡΙΒΩΣ η 3.0.0~beta6!
		if wb_current_version == target_delete_version:
			xbmc.log(f"[Master_Build] Εντοπίστηκε η προβληματική έκδοση {wb_current_version} του {addon_to_delete}. Έναρξη ολικής διαγραφής...", xbmc.LOGINFO)
			
			# 🔔 1. ΕΜΦΑΝΙΣΗ ΕΙΔΟΠΟΙΗΣΗΣ (Πριν σβήσουμε τον φάκελο για να προλάβει να τραβήξει το icon)
			xbmcgui.Dialog().notification(
				"[COLOR red]Απεγκατάσταση[/COLOR]", 
				f"του Πρόσθετου [B][COLOR lime]AliveGR (Beta 6)[/COLOR][/B]", 
				sound=False, 
				icon=wb_icon_path
			)
			xbmc.sleep(1200) # Δίνουμε 1.2 δευτερόλεπτα στο Kodi να κάνει render το notification
			
			# 🔒 2. JSON-RPC DISABLE: Απενεργοποιούμε dynamic το addon για να «ξεκλειδώσει» ο φάκελος από τη μνήμη RAM
			try:
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.video.AliveGR","enabled":false}}')
				xbmc.sleep(500)
			except:
				pass
			
			# 🧼 3. ΟΛΙΚΗ ΔΙΑΓΡΑΦΗ ΤΟΥ ΦΑΚΕΛΟΥ ΑΠΟ ΤΑ ADDONS
			if os.path.exists(wb_folder_path):
				shutil.rmtree(wb_folder_path)
				xbmc.log(f"[Master_Build] [OK] Ο φάκελος του {addon_to_delete} σβήστηκε οριστικά από τον δίσκο.", xbmc.LOGINFO)
				
			# 🔄 4. ΦΡΕΣΚΑΡΙΣΜΑ ΤΟΥ KODI για να καταλάβει αμέσως τη διαγραφή
			xbmc.executebuiltin('UpdateLocalAddons')
			xbmc.sleep(1000)
		else:
			# 🚀 ΑΝ ΕΙΝΑΙ BETA 7, BETA 8 Ή ΕΠΙΣΗΜΗ MATRIX, ΤΟ ΠΡΟΣΠΕΡΝΑΕΙ ΑΚΑΡΙΑΙΑ!
			xbmc.log(f"[Master_Build] Παράκαμψη διαγραφής: Το {addon_to_delete} έχει έκδοση {wb_current_version} (Διαφορετική από την target: {target_delete_version}).", xbmc.LOGINFO)
	else:
		xbmc.log(f"[Master_Build] Παράκαμψη: Το {addon_to_delete} δεν είναι εγκατεστημένο στο σύστημα.", xbmc.LOGINFO)

except Exception as delete_error:
	xbmc.log(f"[Master_Build] Σφάλμα κατά τη μεθοδευμένη διαγραφή του AliveGR: {str(delete_error)}", xbmc.LOGERROR)
xbmc.sleep(500)
