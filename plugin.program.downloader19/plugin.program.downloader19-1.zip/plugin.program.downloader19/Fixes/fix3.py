﻿# ----------------------------------------------------------------------
# 🧼 ΜΕΘΟΔΕΥΜΕΝΗ ΔΙΑΓΡΑΦΗ ΠΡΟΒΛΗΜΑΤΙΚΩΝ ΠΡΟΣΘΕΤΩΝ (FUTURE-PROOF DELETE LAYER)
# ----------------------------------------------------------------------
try:
	import shutil, os, re, xbmcvfs, xbmcgui
	
	addon_to_delete = "plugin.video.whiskeyblues"
	target_delete_version = "0.0.3"
	
	# 🎯 ΝΕΑ, ΑΛΑΝΘΑΣΤΗ ΣΥΝΑΡΤΗΣΗ ΕΚΔΟΣΕΩΝ: Μετατρέπει το "0.0.3" σε καθαρούς αριθμούς [0, 0, 3]
	def clean_wb_version(v_str):
		try:
			return [int(x) for x in re.findall(r'\d+', v_str)]
		except:
			return []

	wb_xml_path = xbmcvfs.translatePath(f'special://home/addons/{addon_to_delete}/addon.xml')
	wb_folder_path = xbmcvfs.translatePath(f'special://home/addons/{addon_to_delete}/')
	wb_icon_path = f'special://home/addons/{addon_to_delete}/icon.png'
	
	# Ο κώδικας προχωράει ΜΟΝΟ αν το πρόσθετο είναι όντως εγκατεστημένο στον δίσκο
	if os.path.exists(wb_xml_path):
		with open(wb_xml_path, 'r', encoding='utf-8') as f:
			wb_xml_content = f.read()
			
		# 🔍 Ανάγνωση τρέχουσας έκδοσης από το XML
		wb_current_version = ""
		wb_version_match = re.search(r'<addon\s+.*?version="(.*?)".*?>', wb_xml_content)
		if wb_version_match:
			wb_current_version = wb_version_match.group(1)
			
		wb_curr_v = clean_wb_version(wb_current_version)
		wb_target_v = clean_wb_version(target_delete_version)
		
		# 🎯 ΚΡΙΤΗΡΙΟ: Διαγραφή ΜΟΝΟ αν η έκδοση είναι <= 0.0.3 (Future-proof)
		if wb_curr_v and wb_target_v and wb_curr_v <= wb_target_v:
			xbmc.log(f"[Master_Build] Εντοπίστηκε η προβληματική έκδοση {wb_current_version} του {addon_to_delete}. Έναρξη ολικής διαγραφής...", xbmc.LOGINFO)
			
			# 🔔 1. ΕΜΦΑΝΙΣΗ ΕΙΔΟΠΟΙΗΣΗΣ (Πριν σβήσουμε τον φάκελο για να προλάβει να τραβήξει το icon)
			xbmcgui.Dialog().notification(
				"[COLOR red]Απεγκατάσταση[/COLOR]", 
				f"του Πρόσθετου [B][COLOR yellow]Whiskey Blues[/COLOR][/B]", 
				sound=False, 
				icon=wb_icon_path
			)
			xbmc.sleep(1000) # Δίνουμε 1 δευτερόλεπτο στο Kodi να κάνει render το notification
			
			# 🔒 2. JSON-RPC DISABLE: Απενεργοποιούμε dynamic το addon για να «ξεκλειδώσει» ο φάκελος από τη μνήμη του Kodi
			try:
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.video.whiskeyblues","enabled":false}}')
				xbmc.sleep(500)
			except:
				pass
			
			# 🧼 3. ΟΛΙΚΗ ΔΙΑΓΡΑΦΗ ΤΟΥ ΦΑΚΕΛΟΥ ΑΠΟ ΤΑ ADDONS
			if os.path.exists(wb_folder_path):
				shutil.rmtree(wb_folder_path)
				xbmc.log(f"[Master_Build] [OK] Ο φάκελος του {addon_to_delete} σβήστηκε οριστικά από τον δίσκο.", xbmc.LOGINFO)
				
			# 🔄 4. ΦΡΕΣΚΑΡΙΣΜΑ ΤΟΥ KODI για να καταλάβει αμέσως τη διαγραφή
			xbmc.executebuiltin('UpdateLocalAddons')
			xbmc.sleep(1000)
		else:
			# Αν στο μέλλον το addon αναβαθμιστεί (π.χ. σε 0.0.4), το build δεν θα το πειράξει!
			xbmc.log(f"[Master_Build] Παράκαμψη διαγραφής: Το {addon_to_delete} έχει νεότερη έκδοση {wb_current_version} (> {target_delete_version}).", xbmc.LOGINFO)
	else:
		xbmc.log(f"[Master_Build] Παράκαμψη: Το {addon_to_delete} δεν είναι εγκατεστημένο στο σύστημα.", xbmc.LOGINFO)

except Exception as delete_error:
	xbmc.log(f"[Master_Build] Σφάλμα κατά τη μεθοδευμένη διαγραφή του Whiskey Blues: {str(delete_error)}", xbmc.LOGERROR)
xbmc.sleep(500)
