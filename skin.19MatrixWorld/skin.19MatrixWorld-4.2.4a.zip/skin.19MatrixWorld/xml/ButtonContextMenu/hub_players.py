﻿import xbmc
import xbmcgui
import xbmcvfs
import os

def set_tmdbh_language(value):
    """Βοηθητική συνάρτηση για αθόρυβη αλλαγή της τιμής στο settings.xml του TMDb Helper"""
    try:
        tmdbh_id = 'plugin.video.themoviedb.helper'
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')
        
        # Σιγουρεύουμε ότι ο φάκελος υπάρχει
        tmdbh_settings_dir = os.path.dirname(tmdbh_settings_xml)
        if not os.path.exists(tmdbh_settings_dir):
            os.makedirs(tmdbh_settings_dir)
            
        # Κατασκευή του XML ανάλογα με την τιμή που δίνουμε (18 ή 12)
        if value == 18:
            clean_xml_content = (
                '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
                '<settings version="1">\n'
                '    <setting id="language" default="true">18</setting>\n'
                '</settings>\n'
            )
        else: # Για την τιμή 12
            clean_xml_content = (
                '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
                '<settings version="1">\n'
                '    <setting id="language">12</setting>\n'
                '</settings>\n'
            )
            
        # Αθόρυβη διαγραφή και επανεγγραφή χωρίς κανένα notification
        if xbmcvfs.exists(tmdbh_settings_xml):
            try:
                xbmcvfs.delete(tmdbh_settings_xml)
            except:
                pass
                
        with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
            f.write(clean_xml_content)
            
    except Exception as e:
        xbmc.log(f"[Master_Build] Αποτυχία dynamic αλλαγής γλώσσας σε {value}: {str(e)}", xbmc.LOGERROR)
        

def main():
    xbuiltin = xbmc.executebuiltin
    
    # 🤫 1. ΑΘΟΡΥΒΟ ΚΛΕΙΔΩΜΑ ΣΤΗΝ ΤΙΜΗ 18 ΣΤΗΝ ΑΡΧΗ
    set_tmdbh_language(18)
    xbmc.sleep(200) # Μικρό sleep για να κάτσει το αρχείο στον δίσκο

    # ⚡ ΑΡΧΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ
    xbmc.sleep(350)
    xbuiltin('Action(Stop)')
    xbuiltin('PlayerControl(Stop)')
    xbmc.sleep(350)

    # =======================================================================
    # ⚙️ ΔΥΝΑΜΙΚΑ ΔΕΔΟΜΕΝΑ (ΟΡΙΖΕΙΣ Ο,ΤΙ ΘΕΛΕΙΣ ΕΔΩ!)
    # =======================================================================
    sound_file = 'special://skin/sounds/BladeRunner.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/Media Player.png'
    title_text = '[COLOR white]Επιλέξτε[/COLOR]'
    msg_text   = '[B][COLOR orange]Player[/COLOR][/B]'
    # =======================================================================

    # 1. 🔒 ΚΛΕΙΣΙΜΟ ΗΥΒ 6199
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(350)

    # 2. 📥 DYNAMIC INJECTION: Γεμίζουμε τη μνήμη του Skin
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # 5. 🔔 ΑΝΟΙΓΜΑ CUSTOM POP-UP (ΑΣΠΙΔΑ 4200) ΠΑΝΩ ΑΠΟ ΤΟ INFO
    xbuiltin('ActivateWindow(4200)')

    # =======================================================================
    # 🚀 3. Η ΑΠΟΛΥΤΗ DIRECT ΕΝΤΟΛΗ (TMDBH CORE INJECTION - ULTRA CHECKMATE)
    # =======================================================================
    # 🎯 FORCE FOCUS LOCK: Σιγουρεύουμε ότι το focus είναι καρφωμένο στη λίστα 8044
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(150)

    # 🕵️‍♂️ ΤΡΑΒΑΜΕ ΤΑ ΔΕΔΟΜΕΝΑ ΑΠΟ ΤΗ ΜΝΗΜΗ ΤΟΥ SKIN (ΕΓΓΥΗΜΕΝΑ ΚΑΙ ΣΤΟ OBSESSION)
    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')
    
    # 🛡️ ULTRA CHECKMATE: Εκτελούμε απευθείας τον πυρήνα του TMDbHelper!
    tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'
    xbuiltin(f'RunScript({tmd_script})')
    
    # ⏳ ΔΙΝΟΥΜΕ ΧΡΟΝΟ ΝΑ ΑΝΟΙΞΕΙ ΤΟ ΠΑΡΑΘΥΡΟ ΜΕ ΤΟΥΣ PLAYERS
    xbmc.sleep(800) # Αυξημένο sleep για να προλάβει να διαβάσει το 18 ο διάλογος

    # 🤫 2. ΑΦΟΥ ΑΝΟΙΞΕΙ, ΤΟ ΓΥΡΝΑΜΕ ΠΑΛΙ ΣΤΟ 12 ΑΘΟΡΥΒΑ
    set_tmdbh_language(12)
    xbmc.sleep(200)

    # =======================================================================
    # 🤖 4. ΠΑΡΑΚΑΜΨΗ ΠΑΡΑΘΥΡΟΥ MANALAB (ΑΝ ΕΜΦΑΝΙΣΤΕΙ)
    # =======================================================================
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(100)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(200)
        xbuiltin('Action(Left)')   
        xbmc.sleep(150)
        xbuiltin('Action(Select)') 

    xbmc.sleep(400) 

if __name__ == '__main__':
    main()
