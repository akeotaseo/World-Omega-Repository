# -*- coding: utf-8 -*-
import xbmc, xbmcgui, socket, importlib

# 1. Αποθηκεύουμε το βασικό παράθυρο, τη διαδρομή του φακέλου και την κατηγορία
start_win = xbmcgui.getCurrentWindowId()
start_folder = xbmc.getInfoLabel('Container.FolderPath')
home_win = xbmcgui.Window(10000)
last_cat_id = xbmc.getInfoLabel('Skin.String(LastFocusedCategory)')

# 2. Κλείνουμε αμέσως όποιο dialog είναι ανοιχτό τώρα
curr_dlg = xbmcgui.getCurrentWindowDialogId()
if curr_dlg != 9999:
	xbmc.executebuiltin(f'Dialog.Close({curr_dlg},true)')
xbmc.executebuiltin('Dialog.Close(all,true)')

xbmcgui.Dialog().notification(
	'[B][COLOR orange]Κλείσιμο όλων...[/COLOR][/B]',
	'[COLOR white]Ακύρωση ενέργειας...[/COLOR]',
	xbmcgui.NOTIFICATION_INFO,
	time=2000,
	sound=False
)

# 3. Παρακολουθούμε έως 5 δευτερόλεπτα (50 x 0.1s):
#    Κλείνει κάθε επόμενο dialog (5004, OK, YesNo κ.λπ.) ΚΑΙ οποιοδήποτε notification πετάξει το script!
quiet_ticks = 0

for i in range(50):
	xbmc.sleep(100)
	closed_something = False

	dlg_id = xbmcgui.getCurrentWindowDialogId()
	if dlg_id != 9999:
		xbmc.executebuiltin(f'Dialog.Close({dlg_id},true)')
		closed_something = True

	# Σβήνει ακαριαία και οποιοδήποτε notification πετάξει το ξένο script (μετά τα πρώτα 0.3s ώστε να φανεί το δικό μας)
	if i >= 3 and xbmc.getCondVisibility('Window.IsVisible(notification)'):
		xbmc.executebuiltin('Dialog.Close(notification,true)')
		closed_something = True

	if closed_something:
		quiet_ticks = 0
	else:
		quiet_ticks += 1
		if quiet_ticks >= 10:
			break

# 4. ΑΚΥΡΩΣΗ ΕΙΣΟΔΟΥ ΣΕ ΠΡΟΣΘΕΤΟ Ή ΝΕΟ ΠΑΡΑΘΥΡΟ
new_win = xbmcgui.getCurrentWindowId()
new_folder = xbmc.getInfoLabel('Container.FolderPath')

if new_win != start_win or (new_folder != start_folder and 'plugin://' in new_folder):
	home_win.setProperty('BlockHomeAutoFocus', 'true')
	xbmc.executebuiltin('Dialog.Close(all,true)')
	xbmc.sleep(100)
	xbmc.executebuiltin('Action(PreviousMenu)' if new_win != start_win else 'Action(Back)')
	xbmc.sleep(300)

	if last_cat_id == '1' and xbmcgui.getCurrentWindowId() == 10000:
		xbmc.executebuiltin('Control.SetFocus(9000,0,absolute)')

	home_win.clearProperty('BlockHomeAutoFocus')

# 5. Ακαριαίος καθαρισμός DNS/Socket της Python (0.001s)
try:
	importlib.reload(socket)
	socket.setdefaulttimeout(6)
except:
	pass

xbmcgui.Dialog().notification(
	'[B][COLOR lime]Έτοιμο![/COLOR][/B]',
	'[COLOR white]Η ενέργεια ακυρώθηκε.[/COLOR]',
	xbmcgui.NOTIFICATION_INFO,
	time=1500,
	sound=False
)
