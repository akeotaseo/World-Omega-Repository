﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import re
import time
import urllib.request
import urllib.parse
import json
import ssl


def set_tmdbh_language(value):
    try:
        tmdbh_id = 'plugin.video.themoviedb.helper'
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')
        if not xbmcvfs.exists(tmdbh_settings_xml):
            return
        with open(tmdbh_settings_xml, 'r', encoding='utf-8') as f:
            xml_content = f.read()
        pattern = r'<setting id="language"[^>]*>.*?</setting>'
        new_setting = f'<setting id="language">{value}</setting>'
        if re.search(pattern, xml_content):
            updated_content = re.sub(pattern, new_setting, xml_content)
        else:
            updated_content = xml_content.replace('</settings>', f'    {new_setting}\n</settings>')
        with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
            f.write(updated_content)
    except Exception:
        pass


def _clean_title(t):
    if not t:
        return ''
    t = re.sub(r'\[COLOR[^\]]*\]|\[/COLOR\]|\[B\]|\[/B\]|\[I\]|\[/I\]', '', t)
    t = re.sub(r'\(\d{4}\)', '', t)
    return t.replace(',', ' ').strip()


def _get_local_tmdb_keys():
    keys = []
    # 1. Έλεγχος αν ο χρήστης έχει βάλει δικό του API key στο TMDbHelper settings.xml
    try:
        s_xml = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper/settings.xml')
        if xbmcvfs.exists(s_xml):
            with open(s_xml, 'r', encoding='utf-8') as f:
                txt = f.read()
            m = re.search(r'<setting id="tmdb_apikey"[^>]*>([^<]+)</setting>', txt)
            if m and len(m.group(1).strip()) == 32:
                keys.append(m.group(1).strip())
    except Exception:
        pass

    # 2. Σάρωση των εγκατεστημένων addons (TMDbHelper, Blacklodge, ExtendedInfo) για ενεργό 32-char hex key
    addon_paths = [
        'special://home/addons/plugin.video.themoviedb.helper/resources/lib',
        'special://home/addons/plugin.video.blacklodge/resources/lib',
        'special://home/addons/script.extendedinfo/resources/lib',
    ]
    for ap in addon_paths:
        real_ap = xbmcvfs.translatePath(ap)
        if not os.path.exists(real_ap):
            continue
        for root, _, files in os.walk(real_ap):
            for fn in files:
                if fn.endswith('.py'):
                    try:
                        with open(os.path.join(root, fn), 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        for found in re.findall(r'["\']([a-f0-9]{32})["\']', content):
                            if found not in keys:
                                keys.append(found)
                        if len(keys) >= 5:
                            break
                    except Exception:
                        pass
            if len(keys) >= 5:
                break
    return keys


def _resolve_tmdb_id(titles, year):
    # 1. Έλεγχος αν υπάρχει ήδη στη μνήμη του Skin ή του Widget 8034
    tid = (
        xbmc.getInfoLabel('Skin.String(HubMovieTMDB)')
        or xbmc.getInfoLabel('Container(8034).ListItem.UniqueID(tmdb)')
        or xbmc.getInfoLabel('Container(8034).ListItem.Property(tmdb_id)')
    ).strip()
    if tid and tid.isdigit():
        return tid

    keys = _get_local_tmdb_keys()
    if not keys:
        return ''

    ctx = ssl._create_unverified_context()
    host = 'https://api.themoviedb.' + 'org/3/search/movie'

    for api_key in keys:
        for t in titles:
            if not t:
                continue
            q = urllib.parse.quote(t)
            attempts = [
                f'{host}?api_key={api_key}&language=el-GR&query={q}',
                f'{host}?api_key={api_key}&language=en-US&query={q}',
            ]
            if year and year.isdigit():
                attempts.insert(0, f'{host}?api_key={api_key}&language=el-GR&query={q}&year={year}')
                attempts.insert(1, f'{host}?api_key={api_key}&language=en-US&query={q}&year={year}')

            for url in attempts:
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                    raw = urllib.request.urlopen(req, timeout=4.0, context=ctx).read().decode('utf-8')
                    data = json.loads(raw)
                    results = data.get('results') or []
                    if results and isinstance(results, list):
                        first = results.pop(0)
                        if isinstance(first, dict) and first.get('id'):
                            return str(first['id'])

                except Exception:
                    continue
    return ''



def main():
    xbuiltin = xbmc.executebuiltin
    start_time = time.time()

    # 1. Σταμάτημα τυχόν ενεργού βίντεο/τρέιλερ
    if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility('Player.HasVideo'):
        xbmc.sleep(300)
        xbuiltin('Action(Stop)')
        xbuiltin('PlayerControl(Stop)')
        xbmc.sleep(300)

    # 2. Διαβάζουμε ΟΛΟΥΣ τους διαθέσιμους τίτλους (Original & Ελληνικό) καθαρισμένους
    orig_title = _clean_title(xbmc.getInfoLabel('Skin.String(HubMovieOrigTitle)') or xbmc.getInfoLabel('Container(8034).ListItem.OriginalTitle'))
    el_title   = _clean_title(xbmc.getInfoLabel('Skin.String(HubMovieTitle)') or xbmc.getInfoLabel('Container(8034).ListItem.Title'))
    movie_title = orig_title or el_title
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)').strip()

    tmdb_id = _resolve_tmdb_id([orig_title, el_title], movie_year)
    # xbmcgui.Dialog().notification('AutoPlay Debug', f'ID: {tmdb_id or "KENO"} | {movie_title}', time=3000)


    # 3. Κλείσιμο του Hub (6199) & άνοιγμα Ασπίδας 4201
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(200)

    sound_file = 'special://skin/sounds/mgm.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/MGM.gif'
    title_text = '[COLOR white]Αυτόματη[/COLOR] [B][COLOR orange]Αναπαραγωγή[/COLOR][/B]'
    msg_text   = '[COLOR deepskyblue]Ελλ. ήχος - Ελλ. Υπότ[/COLOR]'

    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    xbuiltin('ActivateWindow(4201)')
    xbmc.sleep(100)

    set_tmdbh_language(18)
    xbmc.sleep(150)

    # 4. Εκκίνηση με tmdb_id (ώστε το {imdb} να περνάει 100% σωστά στον MicroJen)
    if tmdb_id:
        tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,tmdb_id={tmdb_id},ignore_default=true'
    else:
        tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'


    xbuiltin(f'RunScript({tmd_script})')

    xbmc.sleep(800)
    set_tmdbh_language(12)

    # 5. Ανιχνευτής SelectDialog (Πατάει αυτόματα το 1ο παράθυρο ΚΑΙ το υπο-μενού του MicroJen)
    for _ in range(2):
        dialog_timeout = 0
        while not xbmc.getCondVisibility('Window.IsVisible(selectdialog)') and dialog_timeout < 50:
            xbmc.sleep(150)
            dialog_timeout += 1

        if xbmc.getCondVisibility('Window.IsVisible(selectdialog)'):
            xbmc.sleep(350)
            xbuiltin('Control.SetFocus(6)')
            xbmc.sleep(200)
            xbuiltin('Action(Select)')
            xbmc.sleep(400)
        else:
            break

    # 6. Παράκαμψη τυχόν yes/no διαλόγου
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(150)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(200)
        xbuiltin('Action(Left)')
        xbmc.sleep(100)
        xbuiltin('Action(Select)')

    # 7. Αναμονή αναπαραγωγής & κλείσιμο ασπίδας 4201
    video_timeout = 0
    while not xbmc.Player().isPlayingVideo() and video_timeout < 350:
        xbmc.sleep(100)
        video_timeout += 1

    elapsed_time = time.time() - start_time
    if elapsed_time < 8.0:
        xbmc.sleep(int((8.0 - elapsed_time) * 1000))

    xbuiltin('Dialog.Close(4201)')


if __name__ == '__main__':
    main()
