﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import threading
import sys
import socket


def _force_stop_worker():
    try:
        xbmc.executebuiltin('Playlist.Clear')
        xbmc.executebuiltin('PlayerControl(Stop)')
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
    except Exception:
        pass


def universal_safe_stop():
    play_trailer_after = False
    if len(sys.argv) > 1 and 'play_trailer' in sys.argv[-1]:
        play_trailer_after = True

    win = xbmcgui.Window(10000)
    is_video = xbmc.Player().isPlayingVideo()

    # 1. Καθαρισμός OSD & Trailer flags
    xbmc.executebuiltin('Dialog.Close(musicosd,true)')
    xbmc.executebuiltin('Dialog.Close(videoosd,true)')
    xbmc.executebuiltin('Skin.ResetString(HubMovieTrailer)')
    xbmc.executebuiltin('Skin.ResetString(HubTrailerActive)')

    # 2. Εκτέλεση Stop σε daemon thread ώστε να μην παγώσει ποτέ το UI
    t = threading.Thread(target=_force_stop_worker)
    t.daemon = True
    t.start()

    # 3. Ξεμπλοκάρισμα τυχόν κολλημένων flags δικτύου & monitor
    win.clearProperty('IPServiceRunning')
    win.clearProperty('SysMonBusy')
    try:
        socket.setdefaulttimeout(5)
    except Exception:
        pass

    # 4. Αναμονή μέχρι να κλείσει τελείως ο player
    monitor = xbmc.Monitor()
    max_wait = 2.5 if is_video else 1.2
    waited = 0.0
    while xbmc.Player().isPlaying() and waited < max_wait and not monitor.abortRequested():
        if monitor.waitForAbort(0.25):
            return
        waited += 0.25

    # 5. Δίνουμε 0.5s ανάσα στο Android TV Box να κλείσει τα sockets του stream
    # πριν ζητήσουμε νέο έλεγχο IP/δικτύου (χωρίς UpdateLocalAddons που βαραίνει το Kodi)
    monitor.waitForAbort(0.5)
    win.setProperty('TriggerIPCheck', 'true')

    if play_trailer_after:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        trailer_url = xbmc.getInfoLabel('ListItem.Trailer')
        if trailer_url:
            xbmc.executebuiltin('PlayMedia(' + trailer_url + ')')


if __name__ == '__main__':
    universal_safe_stop()
