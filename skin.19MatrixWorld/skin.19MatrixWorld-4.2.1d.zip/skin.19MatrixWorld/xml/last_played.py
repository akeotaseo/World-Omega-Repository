﻿import xbmc

def last_played():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(200)
    xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(200)
    xbmc.executebuiltin("RunAddon(plugin.video.last_played,return)")

last_played()
