﻿import xbmc,xbmcgui

def aspectratio():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(aspectratio)")
    xbmc.sleep(100)
    xbmc.executebuiltin("Action(aspectratio)")

aspectratio()
