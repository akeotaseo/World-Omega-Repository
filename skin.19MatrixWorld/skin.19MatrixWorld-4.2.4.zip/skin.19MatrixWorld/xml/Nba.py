import xbmc, xbmcgui



def Nba():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]       NBA[/COLOR][/B]',
['[COLOR=blue]NBA[/COLOR] (The Loop)',
 '[COLOR=orange]NBA[/COLOR] (MyIPTV)',
 '[COLOR=red]NBA / Microjen[/COLOR]   [COLOR red]Daddylive[/COLOR] [COLOR green](Auto-Filter)[/COLOR]'
 ])




    if call > -1:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Dialog Spor/DialogLoopNBA.py")')

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().ok('[COLOR=orange]NBA[/COLOR] (MyIPTV)', '[COLOR lime]Επιλέγουμε URL και στη συνέχεια... στα [B][COLOR white]Ζωντανά Κανάλια[/COLOR][/B] ψάχνουμε την κατηγορία που μας ενδιαφέρει.[CR]Σε περίπτωση [COLOR white]Αποτυχίας Σύνδεσης[/COLOR], δοκιμάζουμε άλλο URL')
    xbmcgui.Dialog().notification("[B][COLOR darkorange]GKoBu Tools [/COLOR][/B]", "My[COLOR orangered]IPTV[/COLOR] iLoader", sound=False, icon='https://redditmedia.com')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=World%20Build%20x-treme%20codes%20(ABN)&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fpastebin.com%2fraw%2fR4ai7YMC%22%7d")')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')

def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().notification("[B][COLOR orange]NBA[/COLOR][/B]", "Παρακαλώ περιμένετε...", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    
    # 1. Άνοιγμα του μενού του DaddyLive
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')
    
    # ⏱️ Περιμένουμε να φορτώσει το παράθυρο 10025
    timeout = 10
    while not xbmc.getCondVisibility('Window.IsActive(10025)') and timeout > 0:
        xbmc.sleep(200)
        timeout -= 1
        
    xbmc.sleep(1500) # Αέρας για το UI

    # 2. Στέλνουμε το focus στο Φίλτρο (ID 19) στα αριστερά
    xbmc.executebuiltin('SetFocus(19)')
    xbmc.sleep(400)

    # 3. Πατάμε "OK" για να ανοίξει το πληκτρολόγιο
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(1200)

    # 4. Πληκτρολόγηση της λέξης "nba"
    # Γράμμα n (id 165)
    xbmc.executebuiltin('SetFocus(165)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα b (id 164)
    xbmc.executebuiltin('SetFocus(164)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα a (id 140)
    xbmc.executebuiltin('SetFocus(140)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # 5. Πατάμε το κουμπί "Τέλος" (id 300)
    xbmc.executebuiltin('SetFocus(300)')
    xbmc.sleep(200)
    xbmc.executebuiltin('Action(Select)')
    
    xbmc.sleep(500)
    xbmc.executebuiltin('Action(Right)')
    
    # 6. Ειδοποιήσεις
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR blue]NBA[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')


Nba()
