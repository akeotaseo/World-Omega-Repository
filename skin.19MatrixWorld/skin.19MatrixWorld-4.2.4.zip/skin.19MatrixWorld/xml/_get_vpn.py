# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request

def get_vpn_status():
    try:
        url = 'https://1.1.1.1/cdn-cgi/trace'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=4).read().decode('utf8')
        
        response = response.replace('\r', '')
        lines = response.split('\n')
        ip_addr = 'N/A'
        country_code = 'Unknown'
        
        for line in lines:
            if line.startswith('ip='):
                ip_addr = line.replace('ip=', '').strip()
            elif line.startswith('loc='):
                country_code = line.split('=')[-1].strip().upper()

        if ip_addr != 'N/A' and ip_addr != '':
            xbmcgui.Window(10000).setProperty('MyWANIP', ip_addr)
            
            if country_code and country_code != 'GR' and country_code != 'UNKNOWN':
                xbmcgui.Window(10000).setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
                xbmcgui.Window(10000).setProperty('MyVPNActive', 'true')
            else:
                if xbmcgui.Window(10000).getProperty('MyVPNActive') != 'true':
                    xbmcgui.Window(10000).setProperty('MyVPNState', '')
                    xbmcgui.Window(10000).setProperty('MyVPNActive', 'false')
    except:
        pass

get_vpn_status()
