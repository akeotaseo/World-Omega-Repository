import xbmc
import xbmcvfs
import os

# Ορισμός των IDs
trakt_id = 'script.trakt'
downloader_id = 'plugin.program.downloader19'

if not xbmc.getCondVisibility(f'System.HasAddon({trakt_id})'):
    xbmc.executebuiltin(f'InstallAddon({trakt_id})')
else:
    # Ορίζουμε τη διαδρομή για τον φάκελο addon_data του Downloader 19
    downloader_profile_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{downloader_id}')
    
    if not os.path.exists(downloader_profile_dir):
        try:
            os.makedirs(downloader_profile_dir)
        except Exception:
            pass

    # Νέα σημαία v4 για τη δοκιμή διαγραφής μόνο του settings.xml
    flag_file_path = os.path.join(downloader_profile_dir, '.trakt_first_reset_v4')

    # Έλεγχος αν υπάρχει ήδη η σημαία
    has_reset = os.path.exists(flag_file_path)

    if not has_reset:
        xbmc.log("[Master] Εκτέλεση: Στόχευση και διαγραφή μόνο του settings.xml του Trakt...", xbmc.LOGINFO)
        
        # Εμφάνιση ειδοποίησης στην οθόνη του Kodi
        xbmc.executebuiltin('Notification(World Updater, Καθαρισμός παλιών ρυθμίσεων Trakt!, 5000)')
        
        # Εντοπισμός της ακριβούς διαδρομής του αρχείου settings.xml του Trakt
        trakt_settings_file = xbmcvfs.translatePath(f'special://profile/addon_data/{trakt_id}/settings.xml')
        
        # Αν υπάρχει το αρχείο, το διαγράφουμε απευθείας
        if os.path.exists(trakt_settings_file):
            try:
                os.remove(trakt_settings_file)
                xbmc.log("[Master] Το αρχείο settings.xml του Trakt διαγράφηκε επιτυχώς!", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Master] Αποτυχία διαγραφής του settings.xml: {str(e)}", xbmc.LOGERROR)
        else:
            xbmc.log("[Master] Το αρχείο settings.xml του Trakt δεν βρέθηκε (ήταν ήδη διαγραμμένο).", xbmc.LOGINFO)
        
        # Δημιουργία της σημαίας v4 στον Downloader 19
        try:
            with open(flag_file_path, 'w') as f:
                f.write('done')
            xbmc.log(f"[Master] Η σημαία v4 δημιουργήθηκε στο addon_data του {downloader_id}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Master] Αποτυχία δημιουργίας σημαίας: {str(e)}", xbmc.LOGERROR)

    # Στο τέλος, άνοιξε κανονικά τις ρυθμίσεις του Trakt
    xbmc.executebuiltin(f'Addon.OpenSettings({trakt_id})')
