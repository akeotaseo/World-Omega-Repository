﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os

def main():
    xbuiltin = xbmc.executebuiltin
    
    # 🔒 BLACKLODGE INTERNAL PAGE BYPASS (Η ΔΟΚΙΜΑΣΜΕΝΗ ΣΥΝΤΑΓΗ)
    current_title = xbmc.getInfoLabel('ListItem.Title')
    current_label = xbmc.getInfoLabel('ListItem.Label')
    folder_path = xbmc.getInfoLabel('ListItem.FolderPath')
    
    if current_title == '' or 'Next' in current_label or 'Επόμενη' in current_label or 'page' in current_label:
        if folder_path and folder_path != '':
            # Ανοίγει το εσωτερικό παράθυρο του Blacklodge στη Σελίδα 2 κανονικά όπως το trailer_timer!
            xbuiltin('ActivateWindow(10025,"{}",return)'.format(folder_path))
        else:
            # Fallback αν δεν βρει το path
            xbuiltin('Action(Select)')
        return # 🔥 Σταματάει ακαριαία την εκτέλεση για να μην μπερδεύονται οι Players

    # 🎯 FORCE FOCUS LOCK: Κλειδώνουμε το focus στο 8034 για να διαβάσουμε σωστά
    xbuiltin('Control.SetFocus(8034)')
    xbmc.sleep(100)

    # =======================================================================
    # 🕵️‍♂️ ΑΘΟΡΥΒΟ TRAILER TIMER INJECTION (ΑΠΟΚΛΕΙΣΤΙΚΑ ΓΙΑ ΤΟ WIDGET 8034)
    # =======================================================================
    # Διαβάζουμε τα δεδομένα live από το Container 8034 την ώρα του κλικ
    live_title = xbmc.getInfoLabel('Container(8034).ListItem.Title') or xbmc.getInfoLabel('ListItem.Title')
    live_year  = xbmc.getInfoLabel('Container(8034).ListItem.Year') or xbmc.getInfoLabel('ListItem.Year')
    
    # Αν για κάποιο λόγο είναι άδεια, σταματάμε για ασφάλεια
    if not live_title or live_title == '':
        xbmc.log("[Master_Build] Σφάλμα: Δεν βρέθηκαν δεδομένα στο widget 8034!", xbmc.LOGERROR)
        return
        
    # Εγγράφουμε τα δεδομένα στα Skin Strings ώστε να είναι έτοιμα για το Skin και το TMDb
    xbuiltin(f'Skin.SetString(HubMovieTitle,{live_title})')
    xbuiltin(f'Skin.SetString(HubMovieYear,{live_year})')
    xbmc.sleep(100) # Μικρό sleep για να κάτσουν οι τιμές στη RAM

    # ⚡ ΑΡΧΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ
    xbuiltin('Action(Stop)')
    xbuiltin('PlayerControl(Stop)')
    xbmc.sleep(350)

    # =======================================================================
    # ⚙️ ΔΥΝΑΜΙΚΑ ΔΕΔΟΜΕΝΑ
    # =======================================================================
    sound_file = 'special://skin/sounds/BladeRunner.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/Media Player.png'
    title_text = '[COLOR white]Επιλέξτε[/COLOR]'
    msg_text   = '[B][COLOR orange]Player[/COLOR][/B]'
    # =======================================================================

    # 1. 🔒 ΚΛΕΙΣΙΜΟ ΗΥΒ 6199 (Αν είναι ανοιχτό)
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(350)

    # 2. 📥 DYNAMIC INJECTION: Γεμίζουμε τη μνήμη του Skin
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # =======================================================================
    # 🚀 3. Η ΑΠΟΛΥΤΗ DIRECT ΕΝΤΟΛΗ (TMDBH CORE INJECTION - ULTRA CHECKMATE)
    # =======================================================================
    # Τραβάμε πλέον τις τιμές που μόλις κάναμε Injection με ασφάλεια
    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')
    
    # 🛡️ ULTRA CHECKMATE: Εκτελούμε απευθείας τον πυρήνα του TMDbHelper!
    tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'
    xbuiltin(f'RunScript({tmd_script})')
    
    # ⏳ ΔΙΝΟΥΜΕ ΧΡΟΝΟ ΝΑ ΑΝΟΙΞΕΙ ΤΟ ΠΑΡΑΘΥΡΟ ΜΕ ΤΟΥΣ PLAYERS
    xbmc.sleep(800)

    # =======================================================================
    # 🤖 4. ΠΑΡΑΚΑΜΨΗ ΠΑΡΑΘΥΡΟΥ MANALAB (ΑΝ ΕΜΦΑΝΙΣΤΕΙ)
    # =======================================================================
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(100)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(selectdialog)'):
        xbmc.sleep(400) 
        xbuiltin('Control.SetFocus(6)') 

    xbmc.sleep(400)

if __name__ == '__main__':
    main()
