﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs  # 👈 ΠΡΟΣΘΕΘΗΚΕ ΓΙΑ ΤΙΣ ΔΙΑΔΡΟΜΕΣ XML
import os
import re  # 👈 ΠΡΟΣΘΕΘΗΚΕ ΓΙΑ ΤΗΝ ΑΣΦΑΛΕΙΑ ΤΟΥ REGEX
import time

def set_tmdbh_language(value):
    """Βοηθητική συνάρτηση που αλλάζει ΜΟΝΟ τη γλώσσα στο settings.xml, χωρίς να σβήνει τα υπόλοιπα settings"""
    try:
        tmdbh_id = 'plugin.video.themoviedb.helper'
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')
        
        # Αν το αρχείο δεν υπάρχει καν, το φτιάχνουμε βασικό για ασφάλεια
        if not xbmcvfs.exists(tmdbh_settings_xml):
            tmdbh_settings_dir = os.path.dirname(tmdbh_settings_xml)
            if not os.path.exists(tmdbh_settings_dir):
                os.makedirs(tmdbh_settings_dir)
            with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
                f.write(f'<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n<settings version="1">\n    <setting id="language">{value}</setting>\n</settings>\n')
            return

        # 📖 Διαβάζουμε το υπάρχον αρχείο settings
        with open(tmdbh_settings_xml, 'r', encoding='utf-8') as f:
            xml_content = f.read()

        # 🔍 Ψάχνουμε να βρούμε τη γραμμή της γλώσσας και την αντικαθιστούμε δυναμικά
        pattern = r'<setting id="language"[^>]*>.*?</setting>'
        new_setting = f'<setting id="language">{value}</setting>'
        
        if re.search(pattern, xml_content):
            updated_content = re.sub(pattern, new_setting, xml_content)
        else:
            updated_content = xml_content.replace('</settings>', f'    {new_setting}\n</settings>')

        # 💾 Ξαναγράφουμε το αρχείο με τις αλλαγές, κρατώντας όλα τα άλλα settings άθικτα
        with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
            f.write(updated_content)
            
    except Exception as e:
        xbmc.log(f"[Master_Build] Αποτυχία dynamic αλλαγής γλώσσας σε {value}: {str(e)}", xbmc.LOGERROR)


def main():
    xbuiltin = xbmc.executebuiltin
    start_time = time.time()  # ⏱️ Έναρξη χρονομέτρου

    # 🎯 CHECKMATE
    if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility('Player.HasVideo'):
        xbmc.sleep(400)
        xbuiltin('Action(Stop)')
        xbuiltin('PlayerControl(Stop)')
        xbmc.sleep(400)
    else:
        xbmc.sleep(150)

    # 🤫 1. ΑΘΟΡΥΒΟ ΚΛΕΙΔΩΜΑ ΣΤΗΝ ΤΙΜΗ 18 ΣΤΗΝ ΑΡΧΗ
    set_tmdbh_language(18)
    xbmc.sleep(200)

    # ⚙️ ΔΕΔΟΜΕΝΑ
    sound_file = 'special://skin/sounds/mgm.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/MGM.gif'
    title_text = '[COLOR white]Αυτόματη[/COLOR] [B][COLOR orange]Αναπαραγωγή[/COLOR][/B]'
    msg_text   = '[COLOR blue]GR-SUB[/COLOR] [COLOR red]Blacklodge[/COLOR]'

    # 1. 🔒 ΚΛΕΙΣΙΜΟ ΗΥΒ
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(400) 

    # 2. 📥 INJECTION
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # 🔥 ΑΝΟΙΓΜΑ ΑΣΠΙΔΑΣ 4201
    xbuiltin('ActivateWindow(4201)')
    xbmc.sleep(100) 

    # 🚀 3. DIRECT ΕΝΤΟΛΗ
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(200) 

    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')

    tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'
    xbuiltin(f'RunScript({tmd_script})')

    # ⏳ ΔΙΝΟΥΜΕ ΧΡΟΝΟ ΝΑ ΑΝΟΙΞΕΙ ΤΟ ΠΑΡΑΘΥΡΟ ΚΑΙ ΜΕΤΑ ΤΟ ΓΥΡΝΑΜΕ ΣΤΟ 12
    xbmc.sleep(800)
    set_tmdbh_language(12)
    xbmc.sleep(200)

    # 🕵️‍♂️ 4. Ανιχνευτής SelectDialog
    dialog_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(selectdialog)') and dialog_timeout < 100:
        xbmc.sleep(150) 
        dialog_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(selectdialog)'):
        xbmc.sleep(400) 
        xbuiltin('Control.SetFocus(6)') 
        xbmc.sleep(300) 
        xbuiltin('Action(Select)') 
        xbmc.sleep(300)
        xbuiltin('Control.SetFocus(6)') 
        xbmc.sleep(300) 
        xbuiltin('Action(Select)') 
        xbmc.sleep(300)

    # 🛡️ 5. ΠΑΡΑΚΑΜΨΗ MANALAB
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(150)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(250)
        xbuiltin('Action(Left)')
        xbuiltin('Action(Select)')
        

    xbmc.sleep(300)

    # 🎬 6. ΑΝΙΧΝΕΥΤΗΣ ΑΝΑΠΑΡΑΓΩΓΗΣ
    video_timeout = 0
    while not xbmc.Player().isPlayingVideo() and video_timeout < 400:
        xbmc.sleep(100)
        video_timeout += 1
        if video_timeout > 80 and not xbmc.getCondVisibility('Window.IsVisible(selectdialog)') and not xbmc.Player().isPlayingVideo():
            break

    # =======================================================================
    # ⏱️ 🎯 ΤΟ ΚΛΕΙΔΩΜΑ ΤΩΝ 10" (ΚΑΘΑΡΟ, ΧΩΡΙΣ FLASHES)
    # =======================================================================
    elapsed_time = time.time() - start_time
    if elapsed_time < 10.0:
        remaining_sleep = int((10.0 - elapsed_time) * 1000)
        xbmc.sleep(remaining_sleep)
    
    xbuiltin('Dialog.Close(4201)')


if __name__ == '__main__':
    main()
