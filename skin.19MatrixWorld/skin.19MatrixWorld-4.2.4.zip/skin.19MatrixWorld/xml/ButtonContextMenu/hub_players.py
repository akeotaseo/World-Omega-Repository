﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import re  # 👈 ΠΡΟΣΘΕΘΗΚΕ ΓΙΑ ΤΗΝ ΑΣΦΑΛΕΙΑ ΤΟΥ REGEX

def set_tmdbh_language(value):
    """Βοηθητική συνάρτηση που αλλάζει ΜΟΝΟ τη γλώσσα στο settings.xml, χωρίς να σβήνει τα υπόλοιπα settings"""
    try:
        tmdbh_id = 'plugin.video.themoviedb.helper'
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')
        
        # Αν το αρχείο δεν υπάρχει καν, το φτιάχνουμε βασικό για ασφάλεια
        if not xbmcvfs.exists(tmdbh_settings_xml):
            tmdbh_settings_dir = os.path.dirname(tmdbh_settings_xml)
            if not os.path.exists(tmdbh_settings_dir):
                os.makedirs(tmdbh_settings_dir)
            with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
                f.write(f'<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n<settings version="1">\n    <setting id="language">{value}</setting>\n</settings>\n')
            return

        # 📖 Διαβάζουμε το υπάρχον αρχείο settings
        with open(tmdbh_settings_xml, 'r', encoding='utf-8') as f:
            xml_content = f.read()

        # 🔍 Ψάχνουμε να βρούμε τη γραμμή της γλώσσας και την αντικαθιστούμε δυναμικά
        pattern = r'<setting id="language"[^>]*>.*?</setting>'
        new_setting = f'<setting id="language">{value}</setting>'
        
        if re.search(pattern, xml_content):
            updated_content = re.sub(pattern, new_setting, xml_content)
        else:
            # Αν για κάποιο περίεργο λόγο δεν υπάρχει καθόλου το id="language", το σφηνώνουμε πριν το κλείσιμο
            updated_content = xml_content.replace('</settings>', f'    {new_setting}\n</settings>')

        # 💾 Ξαναγράφουμε το αρχείο με τις αλλαγές, κρατώντας όλα τα άλλα settings άθικτα
        with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
            f.write(updated_content)
            
    except Exception as e:
        xbmc.log(f"[Master_Build] Αποτυχία dynamic αλλαγής γλώσσας σε {value}: {str(e)}", xbmc.LOGERROR)
        

def main():
    xbuiltin = xbmc.executebuiltin
    
    # 🤫 1. ΑΘΟΡΥΒΟ ΚΛΕΙΔΩΜΑ ΣΤΗΝ ΤΙΜΗ 18 ΣΤΗΝ ΑΡΧΗ
    set_tmdbh_language(18)
    xbmc.sleep(200) # Μικρό sleep για να κάτσει το αρχείο στον δίσκο

    # ⚡ ΑΡΧΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ
    xbmc.sleep(350)
    xbuiltin('Action(Stop)')
    xbuiltin('PlayerControl(Stop)')
    xbmc.sleep(350)

    # =======================================================================
    # ⚙️ ΔΥΝΑΜΙΚΑ ΔΕΔΟΜΕΝΑ (ΟΡΙΖΕΙΣ Ο,ΤΙ ΘΕΛΕΙΣ ΕΔΩ!)
    # =======================================================================
    sound_file = 'special://skin/sounds/BladeRunner.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/Media Player.png'
    title_text = '[COLOR white]Επιλέξτε[/COLOR]'
    msg_text   = '[B][COLOR orange]Player[/COLOR][/B]'
    # =======================================================================

    # 1. 🔒 ΚΛΕΙΣΙΜΟ ΗΥΒ 6199
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(350)

    # 2. 📥 DYNAMIC INJECTION: Γεμίζουμε τη μνήμη του Skin
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # 5. 🔔 ΑΝΟΙΓΜΑ CUSTOM POP-UP (ΑΣΠΙΔΑ 4200) ΠΑΝΩ ΑΠΟ ΤΟ INFO
    xbuiltin('ActivateWindow(4200)')

    # =======================================================================
    # 🚀 3. Η ΑΠΟΛΥΤΗ DIRECT ΕΝΤΟΛΗ (TMDBH CORE INJECTION - ULTRA CHECKMATE)
    # =======================================================================
    # 🎯 FORCE FOCUS LOCK: Σιγουρεύουμε ότι το focus είναι καρφωμένο στη λίστα 8044
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(150)

    # 🕵️‍♂️ ΤΡΑΒΑΜΕ ΤΑ ΔΕΔΟΜΕΝΑ ΑΠΟ ΤΗ ΜΝΗΜΗ ΤΟΥ SKIN (ΕΓΓΥΗΜΕΝΑ ΚΑΙ ΣΤΟ OBSESSION)
    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')
    
    # 🛡️ ULTRA CHECKMATE: Εκτελούμε απευθείας τον πυρήνα του TMDbHelper!
    tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'
    xbuiltin(f'RunScript({tmd_script})')
    
    # ⏳ ΔΙΝΟΥΜΕ ΧΡΟΝΟ ΝΑ ΑΝΟΙΞΕΙ ΤΟ ΠΑΡΑΘΥΡΟ ΜΕ ΤΟΥΣ PLAYERS
    xbmc.sleep(800) # Αυξημένο sleep για να προλάβει να διαβάσει το 18 ο διάλογος

    # 🤫 2. ΑΦΟΥ ΑΝΟΙΞΕΙ, ΤΟ ΓΥΡΝΑΜΕ ΠΑΛΙ ΣΤΟ 12 ΑΘΟΡΥΒΑ
    set_tmdbh_language(12)
    xbmc.sleep(200)

    # =======================================================================
    # 🤖 4. ΠΑΡΑΚΑΜΨΗ ΠΑΡΑΘΥΡΟΥ MANALAB (ΑΝ ΕΜΦΑΝΙΣΤΕΙ)
    # =======================================================================
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(100)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(200)
        xbuiltin('Action(Left)')   
        xbmc.sleep(150)
        xbuiltin('Action(Select)') 

    xbmc.sleep(400) 

if __name__ == '__main__':
    main()
