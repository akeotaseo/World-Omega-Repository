﻿import xbmc, sys

# iptvsimple
def kodimate():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.kodimate')):
        installkodimate()
        sys.exit() # 🧼 Κλείνει το script αμέσως μετά την εντολή εγκατάστασης
                      
    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.kodimate')):
        xbmc.executebuiltin('RunScript("script.kodimate")')
        sys.exit() # 🧼 Κλείνει το script αμέσως μετά την εκτέλεση
        
def installkodimate():
    xbmc.executebuiltin('InstallAddon(script.kodimate)')
        
if __name__ == '__main__':
    kodimate()
