﻿import xbmc
import xbmcgui

def main():
    xbuiltin = xbmc.executebuiltin
    

    # ⚡ ΑΡΧΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ
    xbmc.sleep(350)
    xbuiltin('Action(Stop)')
    xbuiltin('PlayerControl(Stop)')
    xbmc.sleep(350)

    # =======================================================================
    # ⚙️ ΔΥΝΑΜΙΚΑ ΔΕΔΟΜΕΝΑ (ΟΡΙΖΕΙΣ Ο,ΤΙ ΘΕΛΕΙΣ ΕΔΩ!)
    # =======================================================================
    sound_file = 'special://skin/sounds/BladeRunner.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/Media Player.png'
    title_text = '[COLOR white]Επιλέξτε[/COLOR]'
    msg_text   = '[B][COLOR orange]Player[/COLOR][/B]'
    # =======================================================================

    # 1. 🔒 ΚΛΕΙΣΙΜΟ ΗΥΒ 6199
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(350)

    # 2. 📥 DYNAMIC INJECTION: Γεμίζουμε τη μνήμη του Skin
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # 5. 🔔 ΑΝΟΙΓΜΑ CUSTOM POP-UP (ΑΣΠΙΔΑ 4200) ΠΑΝΩ ΑΠΟ ΤΟ INFO
    xbuiltin('ActivateWindow(4200)')


    # =======================================================================
    # 🚀 3. Η ΑΠΟΛΥΤΗ DIRECT ΕΝΤΟΛΗ (TMDBH CORE INJECTION - ULTRA CHECKMATE)
    # =======================================================================
    # 🎯 FORCE FOCUS LOCK: Σιγουρεύουμε ότι το focus είναι καρφωμένο στη λίστα 8044
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(150)

    # 🕵️‍♂️ ΤΡΑΒΑΜΕ ΤΑ ΔΕΔΟΜΕΝΑ ΑΠΟ ΤΗ ΜΝΗΜΗ ΤΟΥ SKIN (ΕΓΓΥΗΜΕΝΑ ΚΑΙ ΣΤΟ OBSESSION)
    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')
    
    # 🛡️ ULTRA CHECKMATE: Εκτελούμε απευθείας τον πυρήνα του TMDbHelper!
    # Παρακάμπτει 100% το Context Menu, τα dynamic IDs, τα βέλη και τα Resume Points.
    # Πετάει ακαριαία το selectdialog των Players στην οθόνη για οποιαδήποτε ταινία!
    tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'
    xbuiltin(f'RunScript({tmd_script})')
    xbmc.sleep(500) # Χρόνος να σχεδιαστεί ο διάλογος των Players

    # =======================================================================
    # 🤖 4. ΠΑΡΑΚΑΜΨΗ ΠΑΡΑΘΥΡΟΥ MANALAB (ΑΝ ΕΜΦΑΝΙΣΤΕΙ)
    # =======================================================================
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(100)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(200)
        xbuiltin('Action(Left)')   
        xbmc.sleep(150)
        xbuiltin('Action(Select)') 

    xbmc.sleep(400) 


if __name__ == '__main__':
    main()
