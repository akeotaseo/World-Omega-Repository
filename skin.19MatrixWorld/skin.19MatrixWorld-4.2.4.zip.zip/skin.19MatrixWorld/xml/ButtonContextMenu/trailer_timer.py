﻿import xbmc

def main():

    xbuiltin = xbmc.executebuiltin
    
    # 🕵️‍♂️ ULTRA TIME COMPILER (DYNAMIC PARSER): Διαβάζουμε τη διάρκεια της κανονικής ταινίας από το Widget
    duration_str = xbmc.getInfoLabel('ListItem.Duration')
    
    if duration_str and duration_str != '':
        # Αποθηκεύουμε το αρχικό string (π.χ. 01:54:00 ή 114) στο Skin String για το XML
        xbmc.executebuiltin('Skin.SetString(HubMovieDuration, {})'.format(duration_str))
        
        try:
            import datetime
            minutes = 0
            
            # Αν η διάρκεια έρχεται σε μορφή ωρών/λεπτών/δευτερολέπτων (π.χ. 01:54:00)
            if ":" in duration_str:
                time_parts = duration_str.split(":")
                if len(time_parts) == 3: # hh:mm:ss
                    minutes = (int(time_parts[0]) * 60) + int(time_parts[1])
                elif len(time_parts) == 2: # mm:ss
                    minutes = int(time_parts[0])
            else:
                # Αν έρχεται σε καθαρά λεπτά (π.χ. 114)
                minutes = int(duration_str)
            
            if minutes > 0:
                # 🕒 Υπολογίζουμε dynamic την Ώρα Λήξης με βάση το τρέχον ρολόι του συστήματος
                end_time = datetime.datetime.now() + datetime.timedelta(minutes=minutes)
                end_time_str = end_time.strftime('%H:%M')
                xbmc.executebuiltin('Skin.SetString(HubMovieEndTime, {})'.format(end_time_str))
        except:
            pass


    # =======================================================================
    # 🧹 1. ΒΙΑΙΟ RAM FLUSH & RESET
    # =======================================================================
    xbuiltin('Skin.ResetString(HubMovieTrailer)')
    xbuiltin('Skin.ResetString(HubTrailerActive)')
    xbmc.sleep(50) 

    if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility('Player.HasVideo'):
        xbuiltin('PlayerControl(Stop)')
        xbuiltin('Action(Stop)')
        
        # Περιμένουμε ενεργά να "πεθάνει" το προηγούμενο stream
        for _ in range(20): 
            if not xbmc.Player().isPlayingVideo() and not xbmc.getCondVisibility('Player.HasVideo'):
                break
            xbmc.sleep(50)
    
    # 🎯 FORCE FOCUS LOCK
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(50)

    # =======================================================================
    # 🕵️‍♂️ 2. ΠΑΓΙΔΕΥΣΗ ΝΕΟΥ TRAILER
    # =======================================================================
    trailer_url = xbmc.getInfoLabel('ListItem.Trailer')

    # =======================================================================
    # 🎬 3. ΒΗΜΑ Α: ΕΚΚΙΝΗΣΗ ΤΡΑΙΛΕΡ ΣΤΟ BACKGROUND
    # =======================================================================
    if trailer_url and trailer_url != '':
        xbuiltin(f'Skin.SetString(HubMovieTrailer,{trailer_url})')
        xbmc.sleep(30)
        # 🔒 THE WIDGET HANDSHAKE: Κλειδώνουμε στη RAM ότι η εκκίνηση έγινε από το Widget!
        xbmc.executebuiltin('Skin.SetString(HubFromWidget,"true")')

        # Ξεκινάει το stream
        
        xbuiltin(f'PlayMedia("{trailer_url}",1,windowed="true")')
        xbuiltin('Skin.SetString(HubTrailerActive, true)') # 🎯 ΑΝΑΒΟΥΜΕ ΤΗ ΣΦΡΑΓΙΔΑ ΜΕΣΑ ΣΤΟ SCRIPT

        
        # 🔥 ΚΡΙΣΙΜΟ: Περιμένουμε το Resolve και να αρχίσει να τρέχει ο χρόνος του βίντεο.
        # Μόνο τότε είμαστε σίγουροι ότι το Kodi σταμάτησε να ανοιγοκλείνει παράθυρα!
        video_started = False
        for _ in range(40): # Δίνουμε έως 2 δευτερόλεπτα στο addon (π.χ. YouTube) να φέρει εικόνα
            if xbmc.Player().isPlayingVideo() and xbmc.Player().getTime() > 0:
                video_started = True
                break
            xbmc.sleep(200)
            
        # Αν το Kodi πήγε να το πετάξει fullscreen, το μαζεύουμε ΠΡΙΝ ανοίξουμε το Hub
        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            xbuiltin('Action(SmallWindow)')
            xbmc.sleep(100) # Μικρή ανάσα για να κάτσει το UI

    # =======================================================================
    # 🚀 4. ΒΗΜΑ Β: ΤΟ ΤΕΛΙΚΟ ΑΝΟΙΓΜΑ ΤΟΥ HUB 6199 (ΑΦΟΥ ΟΛΑ ΕΧΟΥΝ ΣΤΑΘΕΡΟΠΟΙΗΘΕΙ)
    # =======================================================================
    # Τώρα που το βίντεο παίζει ήδη windowed, ανοίγουμε το Hub και δεν πρόκειται να κλείσει!
    xbuiltin('ActivateWindow(6199)')
    # if not xbmc.getCondVisibility('Window.IsVisible(6199)'):
        # xbuiltin('ActivateWindow(6199)')
        # xbuiltin('ActivateWindow(6199)')
    
    # Επιθετικό check για να σιγουρευτούμε ότι έκατσε το Hub
    for _ in range(15): 
        if xbmc.getCondVisibility('Window.IsVisible(6199)'):
            break
        xbmc.sleep(50)
        
    if not xbmc.getCondVisibility('Window.IsVisible(6199)'):
        xbuiltin('ActivateWindow(6199)')


if __name__ == '__main__':
    main()

