﻿import xbmc

dynamic_sound = xbmc.getInfoLabel('Skin.String(NotifySound)')

if dynamic_sound:
    xbmc.playSFX(dynamic_sound)
