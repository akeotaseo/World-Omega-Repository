﻿import xbmc
import time


def main():
    xbuiltin = xbmc.executebuiltin
    start_time = time.time()  # ⏱️ Έναρξη χρονομέτρου

    # 🎯 CHECKMATE
    if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility('Player.HasVideo'):
        xbmc.sleep(400)
        xbuiltin('Action(Stop)')
        xbuiltin('PlayerControl(Stop)')
        # xbuiltin('Action(Back)')
        xbmc.sleep(400)
    else:
        xbmc.sleep(150)

    # ⚙️ ΔΕΔΟΜΕΝΑ
    sound_file = 'special://skin/sounds/mgm.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/MGM.gif'
    title_text = '[COLOR white]Αυτόματη[/COLOR] [B][COLOR orange]Αναπαραγωγή[/COLOR][/B]'
    msg_text   = '[COLOR blue]GR-SUB[/COLOR] [COLOR red]Blacklodge[/COLOR]'

    # 1. 🔒 ΚΛΕΙΣΙΜΟ ΗΥΒ
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(400) 

    # 2. 📥 INJECTION
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # 🔥 ΑΝΟΙΓΜΑ ΑΣΠΙΔΑΣ 4201
    xbuiltin('ActivateWindow(4201)')
    xbmc.sleep(100) 

    # 🚀 3. DIRECT ΕΝΤΟΛΗ
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(200) 

    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')

    tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={movie_title},year={movie_year},ignore_default=true'
    xbuiltin(f'RunScript({tmd_script})')

    # 🕵️‍♂️ 4. Ανιχνευτής SelectDialog
    dialog_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(selectdialog)') and dialog_timeout < 100:
        xbmc.sleep(150) 
        dialog_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(selectdialog)'):
        xbmc.sleep(400) 
        xbuiltin('Control.SetFocus(6)') 
        xbmc.sleep(200) 
        xbuiltin('Action(Select)') 
        xbmc.sleep(300)

    # 🛡️ 5. ΠΑΡΑΚΑΜΨΗ MANALAB
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(150)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(250)
        xbuiltin('Action(Left)')
        xbuiltin('Action(Select)')

    xbmc.sleep(300)

    # 🎬 6. ΑΝΙΧΝΕΥΤΗΣ ΑΝΑΠΑΡΑΓΩΓΗΣ
    video_timeout = 0
    while not xbmc.Player().isPlayingVideo() and video_timeout < 400:
        xbmc.sleep(100)
        video_timeout += 1
        if video_timeout > 80 and not xbmc.getCondVisibility('Window.IsVisible(selectdialog)') and not xbmc.Player().isPlayingVideo():
            break

    # =======================================================================
    # ⏱️ 🎯 ΤΟ ΚΛΕΙΔΩΜΑ ΤΩΝ 10" (ΚΑΘΑΡΟ, ΧΩΡΙΣ FLASHES)
    # =======================================================================
    # Περιμένουμε ομαλά στο παρασκήνιο μέχρι το ρολόι να πιάσει τα 10" συνολικά.
    elapsed_time = time.time() - start_time
    if elapsed_time < 10.0:
        remaining_sleep = int((10.0 - elapsed_time) * 1000)
        xbmc.sleep(remaining_sleep)
    
    # Τώρα στέλνουμε το οριστικό κλείσιμο
    xbuiltin('Dialog.Close(4201)')


if __name__ == '__main__':
    main()
