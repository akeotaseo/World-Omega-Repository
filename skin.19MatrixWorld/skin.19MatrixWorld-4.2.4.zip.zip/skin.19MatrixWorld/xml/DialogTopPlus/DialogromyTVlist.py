﻿import xbmc, xbmcgui
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmcgui.Dialog().notification("[B][COLOR yellow]romyTVlist[/COLOR][/B]", "IPTV", sound=False, icon='special://home/addons/plugin.video.romyTVlist/icon.gif')

def romyTVlist():




    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=yellow]~ romyTVlist ~[/COLOR][/B]', 
['[B]romyTVlist[/B]'
 '     '
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.video.romyTVlist","enabled":true}}')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    # xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romyTVlist/")')
    # xbmc.sleep(12000)
    # xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    # xbmc.sleep(4000)

def click_2():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.video.romyTVlist","enabled":true}}')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    # xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romyTVlist/")')
    # xbmc.sleep(12000)
    # xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    # xbmc.sleep(4000)

romyTVlist()

