﻿import xbmc, xbmcgui

def DialogLoopNBA():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/https://loopaddon.uk/files/k19/xmls/NBAZone19/nba.json")')
    xbmcgui.Dialog().notification("[B][COLOR green]Loop[/COLOR][/B]", "[COLOR blue]NBA[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR green]Loop[/COLOR][/B]", "[COLOR blue]NBA[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR green]Loop[/COLOR][/B]", "[COLOR blue]NBA[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
DialogLoopNBA()
